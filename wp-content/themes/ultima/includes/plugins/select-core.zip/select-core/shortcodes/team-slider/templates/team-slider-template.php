<div <?php ultima_qodef_class_attribute($holder_classes); ?>>
    <div
        class="qodef-team-slider simple" <?php echo ultima_qodef_get_inline_attrs($data_attrs); ?>>
        <?php echo do_shortcode($content); ?>
    </div>
</div>