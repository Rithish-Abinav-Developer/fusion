<?php
include_once QODE_CORE_ABS_PATH.'/shortcodes/fullscreen-sections/fullscreen-sections.php';
include_once QODE_CORE_ABS_PATH.'/shortcodes/fullscreen-sections/fullscreen-sections-item.php';
include_once QODE_CORE_ABS_PATH.'/shortcodes/fullscreen-sections/fullscreen-sections-item-slide.php';