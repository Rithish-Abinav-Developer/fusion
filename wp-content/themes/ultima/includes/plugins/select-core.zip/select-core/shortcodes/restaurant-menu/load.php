<?php
require_once QODE_CORE_ABS_PATH.'/shortcodes/restaurant-menu/menu.php';
require_once QODE_CORE_ABS_PATH.'/shortcodes/restaurant-menu/item.php';
