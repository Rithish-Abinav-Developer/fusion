<div class="qodef-accordion-holder clearfix <?php echo esc_attr($acc_class) ?> <?php echo esc_attr($type_class) ?>" <?php ultima_qodef_inline_style($acc_background_color); ?>>
    <?php echo do_shortcode($content); ?>
</div>