<?php

include_once QODE_CORE_ABS_PATH.'/shortcodes/blog-list/blog-list.php';