<?php

include_once QODE_CORE_ABS_PATH.'/shortcodes/product-list-carousel/product-list-carousel.php';