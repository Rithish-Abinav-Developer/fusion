<?php

include_once QODE_CORE_ABS_PATH.'/shortcodes/team/team.php';