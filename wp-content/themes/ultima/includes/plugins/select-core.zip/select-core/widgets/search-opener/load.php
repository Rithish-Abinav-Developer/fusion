<?php

require_once QODE_CORE_ABS_PATH . '/widgets/search-opener/search-opener.php';
