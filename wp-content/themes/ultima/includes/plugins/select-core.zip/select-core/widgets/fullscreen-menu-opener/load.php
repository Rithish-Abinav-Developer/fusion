<?php

require_once QODE_CORE_ABS_PATH . '/widgets/fullscreen-menu-opener/full-screen-menu-opener.php';

