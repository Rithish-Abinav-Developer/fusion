jQuery(document).ready(function($) {
    $('.cpicker').colorpicker({
        format: 'hex'
    });
});