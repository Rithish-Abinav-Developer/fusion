<?php

// Silence is golden.

?>